MONEY OS — Private Finance Planner (Lifetime)
=============================================

YOUR UNLOCK CODE:  MOS-2496-FOREVER
  Use it on your PHONE: open the web app
  https://mataz0.github.io/matas-demo/moneyos/app/
  tap "Enter your unlock code" and paste the code above.
  That page becomes the full app — no file needed on mobile.
  (Please keep the code to yourself — it's what you paid for.)

WHAT'S IN THIS FOLDER
  MoneyOS.html        The app. Double-click it — it opens in your browser.
  START-HERE.html     Your 10-minute setup guide. Open this first.
  sample-import.csv   A ready-made CSV so you can try the importer straight away.
  README.txt          This file.

FIRST STEPS
  1. Open START-HERE.html and follow it. It takes about ten minutes.
  2. Or jump straight in: open MoneyOS.html, press "Load sample data",
     then tap the chat button and type "guide".

WHAT YOU BOUGHT
  - Unlimited entries: transactions, goals, debts, holdings
  - Recurring transactions (rent, salary — added each month in one tap)
  - Custom categories (rename, add your own, pick emojis)
  - CSV import with automatic categorisation (EU and US bank formats)
  - Live prices for stocks, ETFs and crypto — no keys, no accounts
  - Backup and Restore to a file you control
  - Works offline, on Mac, Windows, iPhone, Android — any browser
  - Free updates for version 1 (the app tells you when one is out)

TWO HABITS
  - Press "Save snapshot" once a month — it builds your wealth curve.
  - Press "Backup" once a week — your data lives only on your device,
    so that backup file is your only copy. Keep it in a cloud folder.
    (The app will remind you if you forget.)

PRIVACY
  Money OS has no server and no accounts. Your numbers stay in your browser
  and are never uploaded. The only network traffic is public data downloads:
  market prices and a version check — identical for every user, with nothing
  about you in them. Verify with F12 → Network anytime.

HELP
  matasbuika1@gmail.com — a human replies within hours.
  30-day money-back guarantee, no questions asked.

DISCLAIMER
  For informational and educational purposes only. Not financial, investment,
  tax, or legal advice.
