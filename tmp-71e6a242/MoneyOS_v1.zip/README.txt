MONEY OS — Private Finance Planner (Lifetime)
=============================================

WHAT'S IN THIS FOLDER
  MoneyOS.html        The app. Double-click it — it opens in your browser.
  START-HERE.html     Your 10-minute setup guide. Open this first.
  sample-import.csv   A ready-made CSV so you can try the importer straight away.
  README.txt          This file.

FIRST STEPS
  1. Open START-HERE.html and follow it. It takes about ten minutes.
  2. Or jump straight in: open MoneyOS.html, press "Load sample data",
     then tap the chat button and type "guide".

WHAT YOU BOUGHT
  - Unlimited entries: transactions, goals, debts, holdings
  - CSV import with automatic categorisation
  - Backup and Restore to a file you control
  - Works offline, on Mac, Windows, iPhone, Android — any browser
  - Free updates for version 1
  (The online preview on our website is deliberately limited. This file is not.)

TWO HABITS
  - Press "Save snapshot" once a month — it builds your wealth curve.
  - Press "Backup" once a week — your data lives only on your device,
    so that backup file is your only copy. Keep it in a cloud folder.

PRIVACY
  Money OS has no server. Your numbers stay in your browser and are never
  uploaded. To verify: open the app, press F12, choose Network, use the app —
  you will see zero requests.

HELP
  matasbuika1@gmail.com — a human replies within hours.
  30-day money-back guarantee, no questions asked.

DISCLAIMER
  For informational and educational purposes only. Not financial, investment,
  tax, or legal advice.
