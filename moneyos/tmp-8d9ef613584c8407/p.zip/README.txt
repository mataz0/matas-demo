MONEY OS — Quick start
1. Double-click MoneyOS.html — it opens in your browser. That's it.
2. Works on Mac, Windows, iPhone, Android. No installation, no account.
3. Your data is saved in this browser automatically. Use the Backup button weekly.
4. Moving to another device? Backup → send the .json to yourself → Restore.
Support: matasbuika1@gmail.com · 30-day money-back guarantee.
